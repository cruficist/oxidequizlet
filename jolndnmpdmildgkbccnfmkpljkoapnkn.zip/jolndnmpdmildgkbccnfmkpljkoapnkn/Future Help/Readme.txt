Hello Mr. Coder!

How are you doing today? I hope you are doing all right.
These files are some useful things that I wanted to include, but haven't implemented.
If you want to contribute, please message me on Discord.

I would be glad to answer you questions so please ask away.